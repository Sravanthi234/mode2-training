package com.pack.student.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pack.student.dao.AcademyDao;
import com.pack.student.dto.StudentandAcademy;
import com.pack.student.model.Academy;
import com.pack.student.model.Student;

@Service
public class AcademyService {
	@Autowired
	private AcademyDao academyDao;
	
	
	@Transactional
	public void addAcademy(Academy academy) {
		
		academyDao.addAcademy(academy);
		
	}

}
