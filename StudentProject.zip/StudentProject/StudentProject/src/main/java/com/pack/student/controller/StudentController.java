package com.pack.student.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pack.student.model.Student;
import com.pack.student.service.AcademyService;
import com.pack.student.service.StudentService;
import com.pack.student.dto.StudentandAcademy;
import com.pack.student.model.Academy;
import com.pack.student.model.College;


@Controller
public class StudentController {
private static final Logger logger = LoggerFactory.getLogger(StudentController.class);

private static final String Academy = null;
	
	@Autowired
	private StudentService studentService;
	@Autowired
	private AcademyService academyservice;
	
	private Map<String, StudentandAcademy> student = null;

	public StudentController() {
		student = new HashMap<String, StudentandAcademy>();
	}
	
	
	@ModelAttribute("student1")
	public StudentandAcademy createStudentModel() {
		// ModelAttribute value should be same as used in the empSave.jsp
		return new StudentandAcademy();
	}
	/*@RequestMapping(value = "/student/add", method = RequestMethod.GET)
	public String addStudent(Model model) {
		logger.info("Returning studentdetails.jsp page");
		// model.addAttribute("user", new User());
		return "studentdetails";
	}*/
	/*@RequestMapping(value = "/student/insert", method = RequestMethod.POST)
	public String saveStudentAction(@ModelAttribute("student") @Validated Student student, BindingResult bindingResult,
			Model model) {
	
		if (bindingResult.hasErrors()) {
			logger.info("Returning studentdetails.jsp page");
			return "studentdetails";
		}
		logger.info("Returning success.jsp page");
		model.addAttribute("student", student);
		// customers.put(customer.getEmail(), customer);
		this.studentService.addStudent(student);
		return "success";
	}*/
	@RequestMapping(value = "/student/academy/add", method = RequestMethod.GET)
	public String addStudentandAcademy(Model model) {
		logger.info("Returning studentandacademy page");
		//model.addAttribute("user", new StudentandAcademy());
		return "StudentandAcademy";
	}
	@RequestMapping(value = "/student/academy/save.do", method = RequestMethod.POST)
	public String addStudent(@ModelAttribute("student1") @Validated StudentandAcademy  stdacd, BindingResult bindingResult,
			Model model) {
		//Academy academy=new Academy();
		if (bindingResult.hasErrors()) {
			logger.info("Returning studentdetails.jsp page");
			return "StudentandAcademy";
		}
		logger.info("Returning success.jsp page");
		ModelMapper mapper=new ModelMapper();
		Student student=mapper.map(stdacd, Student.class);
		Academy academy=mapper.map(stdacd, Academy.class);
		model.addAttribute("student1", stdacd);
		this.studentService.addStudent(student,academy);
		//this.academyservice.addAcademy(academy);
		return "success";
	}
	@RequestMapping(value="/student/details",method=RequestMethod.GET)
	public String getStudentDetails(@ModelAttribute("student")@Validated Student student) {
		 return "Details";
	}
	@RequestMapping(value="/student/place/{USN}",method=RequestMethod.GET)
	public String StudentDetails(@PathVariable(value="USN") String usn,@ModelAttribute("student")@Validated Student student,Model model) {
		 String place=studentService.getPlace(usn);
		 model.addAttribute("place",place);
		 return "Place";
	}
	/*@RequestMapping(value="/student/place/{pageno}/{pagesize}",method=RequestMethod.GET)
	public String StudentDetailsbyPaging(@PathVariable(value="pageno") String pageno,@PathVariable(value="pagesize") String pagesize,@ModelAttribute("student")@Validated Student student,Model model) {
		 studentService.getDetailsbyPage(pageno,pagesize);
		 return "Place";
	}*/
	@RequestMapping(value= "/student/{pageno}/{pagesize}", method= RequestMethod.GET) 
    public String paginate(@PathVariable(value="pageno") int pageno,@PathVariable(value="pagesize") int pagesize,Model model){      
        if(pageno == 1) {
            // do nothing!
        } else {            
            pageno= (pageno-1)*pagesize+1;  
        }
 
        List<Student> list = studentService.getDetailsbyPage(pageno, pagesize);
        model.addAttribute("msg",list);
        return "ListbyPage";
    }
}
