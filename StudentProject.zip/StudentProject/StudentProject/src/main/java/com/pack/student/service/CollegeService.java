package com.pack.student.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.student.dao.CollegeDao;
import com.pack.student.model.College;
@Service
public class CollegeService {
	@Autowired
	private CollegeDao collegeDao;
	@Transactional
	public void addCollege(College college) {
		// TODO Auto-generated method stub
		collegeDao.addCollege(college);
	}

}
