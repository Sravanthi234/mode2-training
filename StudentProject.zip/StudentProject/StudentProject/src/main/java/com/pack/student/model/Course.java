package com.pack.student.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="course")
public class Course  {
@Id
private String collegecode;

private String coursename;

public String getCollegecode() {
	return collegecode;
}

public void setCollegecode(String collegecode) {
	this.collegecode = collegecode;
}

public String getCoursename() {
	return coursename;
}

public void setCoursename(String coursename) {
	this.coursename = coursename;
}





}
