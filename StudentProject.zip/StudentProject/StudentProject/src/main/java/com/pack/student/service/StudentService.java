package com.pack.student.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pack.student.dao.StudentDao;
import com.pack.student.dto.StudentandAcademy;
import com.pack.student.model.Academy;
import com.pack.student.model.College;
import com.pack.student.model.Student;

@Service
public class StudentService {
	@Autowired
	private StudentDao studentDao;
	
	
	@Transactional
	public void addStudent(Student student,Academy academy) {
		studentDao.addStudent(student,academy);
		
	}
	/*
	 * @Transactional public List<College> studentdetails(String usn) { return
	 * studentDao.getStudentplaceDetails(usn); }
	 */
	public String  getPlace(String usn){
		System.out.println("clgplace");
		return studentDao.getStudentPlace(usn);
	}
	public List<Student> getDetailsbyPage(int pageno, int pagesize) {
		// TODO Auto-generated method stub
		return studentDao.getStudentByPage(pageno,pagesize);
	}
}
