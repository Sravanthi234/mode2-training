package com.pack.student.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "academy")
public class Academy {
@Id
private String USN;
private String course;
private int sem;
public String getUSN() {
	return USN;
}
public void setUSN(String uSN) {
	USN = uSN;
}
public String getCourse() {
	return course;
}
public void setCourse(String course) {
	this.course = course;
}
public int getSem() {
	return sem;
}
public void setSem(int sem) {
	this.sem = sem;
}


}
