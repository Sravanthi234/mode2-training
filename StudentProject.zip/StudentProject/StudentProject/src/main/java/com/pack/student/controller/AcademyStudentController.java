package com.pack.student.controller;

public class AcademyStudentController {

}
