package com.pack.student.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pack.student.dto.StudentandAcademy;
import com.pack.student.model.Academy;
import com.pack.student.model.College;
import com.pack.student.model.Student;


@Repository
public class StudentDao {

		private static final Logger logger = LoggerFactory.getLogger(StudentDao.class);
		//ModelMapper mapper1=new ModelMapper();
		@Autowired
		private SessionFactory sessionFactory;
		
		public void setSessionFactory(SessionFactory sf){
			this.sessionFactory = sf;
		}

		
		public void addStudent(Student student,Academy academy) {
			Session session = this.sessionFactory.getCurrentSession();
			//mapper1.map(student,StudentandAcademy.class);
			session.persist(student);
			session.persist(academy);
			logger.info("Student added successfully");
		}
	/*
	 * @SuppressWarnings("unchecked") public List<College>
	 * getStudentplaceDetails(String usn){ List<College> lt=new
	 * ArrayList<College>(); Session session=this.sessionFactory.openSession();
	 * String query="from Student where rollno=:usn";
	 * 
	 * @SuppressWarnings("unchecked") Query query1=(Query)
	 * session.createQuery(query); ((org.hibernate.Query)
	 * query1).setString("usn",usn); List results=query1.getResultList();
	 * List<Student> List=session.createQuery("hql").list();
	 * 
	 * @SuppressWarnings("unchecked") List<College>
	 * clgList=session.createQuery("from College").list(); for(int
	 * i=0;i<List.size();i++) { if(((Student)
	 * results.get(i)).getRollno().split(clgList.get(i).getCollegecode()) != null){
	 * lt=(java.util.List<College>) session.createQuery("from College"); } } return
	 * lt; }
	 */
		@SuppressWarnings("unchecked")
		public String  getStudentPlace(String usn){
			Session session = this.sessionFactory.openSession();
			System.out.println("student");
			String collegename=usn.substring(0,4);
			System.out.println(collegename);
			String collegeplace = null;
			List<College> clgList=new ArrayList<College>();
			//Session session = this.sessionFactory.getCurrentSession();
			clgList=session.createQuery("from College").list();
			for(int i=0;i<clgList.size();i++){
				System.out.println(clgList.get(i).getCollegecode());
				if(collegename.equals(clgList.get(i).getCollegecode())){
					collegeplace= clgList.get(i).getCollegeplace();
					System.out.println(collegeplace);
				}
		
			}
			System.out.println(collegeplace);
			return collegeplace;
		}


		public List<Student> getStudentByPage(int pageno,int pagesize) {
			// TODO Auto-generated method stub
			Session session = sessionFactory.openSession();
			Query query = session.createQuery("From Student");
			query.setFirstResult(pageno);
			query.setMaxResults(pagesize);
			List<Student> l1=query.list();
			System.out.println(l1);
			return query.list();
		}



		
}
