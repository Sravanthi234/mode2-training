package com.pack.student.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.student.dao.CourseDao;
import com.pack.student.model.Course;

@Service
public class CourseService {
	@Autowired
	private CourseDao courseDao;
	@Transactional
	
	public void addCourse(Course course) {
		// TODO Auto-generated method stub
		courseDao.addCourse(course);
	}

}
