package com.pack;

public class StaticWithoutArg {
	public static void display()
	{
		System.out.println("Calculating....");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceStatic obj=StaticWithoutArg::display;
        obj.say();
	}
}

