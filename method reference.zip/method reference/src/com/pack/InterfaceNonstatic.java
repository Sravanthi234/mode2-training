package com.pack;

public interface InterfaceNonstatic {
	void display();

}
