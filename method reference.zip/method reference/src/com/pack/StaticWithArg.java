package com.pack;

import java.util.function.BiFunction;

class addition
{
  public static int add(int i,int j)
  {
	return i+j;
  }
}
public class StaticWithArg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BiFunction<Integer, Integer, Integer> adder = addition::add;
		int result = adder.apply(10, 20);
		System.out.println(result);
		
	}
}
	

