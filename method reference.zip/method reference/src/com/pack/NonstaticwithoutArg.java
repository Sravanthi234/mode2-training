package com.pack;

public class NonstaticwithoutArg {
	public void run()
	{
		System.out.println("this is non-static method");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NonstaticwithoutArg objc=new NonstaticwithoutArg();
		InterfaceNonstatic obji=objc::run;
		obji.display();
	}

}
