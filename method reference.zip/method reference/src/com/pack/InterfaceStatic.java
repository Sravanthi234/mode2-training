package com.pack;

public interface InterfaceStatic {
	void say();

}
