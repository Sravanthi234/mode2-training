package com.pack;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class CustomerPackUsingLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter account number");
		Scanner sc=new Scanner(System.in);
		String a="";
		List<String> list1=new ArrayList<String>();
		List<CustomerDetails> customer=new ArrayList<CustomerDetails>();
		int n=sc.nextInt();
		for(int i=0;i<=2;i++)
		{
			a=sc.next();
			list1.add(a);
		}
		List l1=list1.stream().map(i->("SBI"+i)).filter(j->j.length()==8).collect(Collectors.toList());
		System.out.println("Valid accounts"+l1);
		List l2=list1.stream().map(i->("SBI"+i)).filter(j->j.length()!=8).collect(Collectors.toList());
		System.out.println("InValid accounts"+l2);
		CustomerDetails c;
		for(int i=0;i<=2;i++)
		{
			String name=sc.next();
			int age=sc.nextInt();
			String phone=sc.next();
			c=new CustomerDetails(name,age,phone);
			customer.add(c);
		}
		List<CustomerDetails> valid=customer.stream().filter(x->((x.name.matches("[A-Z][a-z]*"))&&(x.age>=18)&&(x.phone.length()==10))).collect(Collectors.toList());
		for(int i=0;i<l1.size()&&i<valid.size();i++)
		{
			String accnum=(String)l1.get(i);
			valid.get(i).accnum=accnum;
		}
		System.out.println("Enter customer name to be withdraw:");
		List<Float> count=new ArrayList<Float>();
		String str=sc.next();
		int num=0,x=0;
		for(int i=0;i<valid.size();i++)
		{
			if(customer.get(i).name.equals(str))
			{
				do
				{
					System.out.println("1.withdraw  2.balance  3.exit");
					num=sc.nextInt();
					switch(num){
					case 1: System.out.println("Enter amount:");
					         float amt=sc.nextFloat();
					         float amountwithdraw=customer.get(i).withdrawAmount(amt);
					         customer.get(i).amount=amountwithdraw;
					         count.add(amt);
					         break;
					case 2:System.out.println(customer.get(i).amount);
					        break;
					case 3:System.out.println("you have done "+count.size()+" transactions");
					       System.out.println("previous transactions are:");
					       for(int j=0;j<count.size();j++)
					       {
				               System.out.println("amount withdraw:"+count.get(j));	    	   
					       }
					       break;
					default:System.out.println("sorry!try again");
					        break;
					}
				}while(!(num==3));
			}
		 }
		for(int i=0;i<valid.size();i++)
		{
			System.out.println(""+valid.get(i).name+" "+valid.get(i).age+" "+valid.get(i).phone);
		}
	}
}
