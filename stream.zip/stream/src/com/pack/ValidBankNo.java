package com.pack;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ValidBankNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		List<Integer> list1=new ArrayList<Integer>();
		System.out.println("Enter numbers");
		int n=sc.nextInt();
		for(int i=0;i<=n;i++)
		{
			list1.add(sc.nextInt());
		}
		System.out.println(list1);
		System.out.println("Valid accounts");
		List l1=list1.stream().map(i->("SBI"+i)).filter(j->j.length()==8).collect(Collectors.toList());
	    System.out.println(l1);
	    System.out.println("Invalid accounts");
		List l2=list1.stream().map(i->("SBI"+i)).filter(j->j.length()!=8).collect(Collectors.toList());
	    System.out.println(l2);
	}

}
