package com.pack;

public class CustomerDetails {

	String name;
	int age;
	String phone;
	String accnum;
	float amount=50000;
	public CustomerDetails(String name,int age,String phone)
	{
		super();
		this.name=name;
		this.age=age;
		this.phone=phone;
	}
	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}
	public float withdrawAmount(float amt) {
		// TODO Auto-generated method stub
		return 0;
	}

}
