package com.pack;

import java.util.ArrayList;
import java.util.List;

public class StreamwithLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list1=new ArrayList<Integer>();
		list1.add(3);
		list1.add(4);
		list1.add(5);
		list1.add(6);
		List<String> list2=new ArrayList<String>();
		list2.add("sai");
		list2.add("ram");
		list2.add(" ");
		list1.stream(). filter(i->(i%3==0)).forEach(System.out::println);
		list2.stream().filter(s->(s!=" ")).forEach(System.out::println);

	}

}
