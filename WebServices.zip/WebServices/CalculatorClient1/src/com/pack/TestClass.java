package com.pack;

import java.rmi.RemoteException;

public class TestClass {
public static void main(String[] args) {
   try{
	   
	CalculatorServiceStub stub=new CalculatorServiceStub();
	CalculatorServiceStub.Add params1=new CalculatorServiceStub.Add();
	params1.setA(20);
	params1.setB(10);
	CalculatorServiceStub.AddResponse response1=stub.add(params1);
	int result=response1.get_return();
	System.out.println("addition is: "+ result);
	
	
	CalculatorServiceStub.Sub params2=new CalculatorServiceStub.Sub();
	params2.setA(20);
	params2.setB(10);
	CalculatorServiceStub.SubResponse response2=stub.sub(params2);
	int result2=response2.get_return();
	System.out.println("subtraction is: "+ result2);
	
	
	CalculatorServiceStub.Mul params3=new CalculatorServiceStub.Mul();
	params3.setA(20);
	params3.setB(10);
	CalculatorServiceStub.MulResponse response3=stub.mul(params3);
	int result3=response3.get_return();
	System.out.println("multiplication is: "+ result3);

	CalculatorServiceStub.Div params4=new CalculatorServiceStub.Div();
	params4.setA(20);
	params4.setB(10);
	CalculatorServiceStub.DivResponse response4=stub.div(params4);
	int result4=response4.get_return();
	System.out.println("division is: "+ result4);
	
	
	}catch(RemoteException e){
		e.printStackTrace();
	  }
   
    }

}
