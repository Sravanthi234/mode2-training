package com.pack.config;

import org.springframework.context.annotation.Configuration;
//import static springfox.documentation.builders.PathSelectors.regex;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
	
	public Docket movieAPI(){
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.apis(RequestHandlerSelectors.basePackage(com.application.moviebooking.controller))
				.paths(regex("/*"))
				.build();
	}
}
