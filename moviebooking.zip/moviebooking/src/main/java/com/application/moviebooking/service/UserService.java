package com.application.moviebooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.moviebooking.DAO.UserDao;
import com.application.moviebooking.model.User;
@Service
public class UserService {
	
	@Autowired
	UserDao userDao;
	
	public String addUserDetails(User user){
		//user.setUserid(user.getUserid());
		//user.setName(user.getName());
		//user.setPhoneno(user.getPhoneno());
		//user.setEmail(user.getEmail());
		userDao.save(user);
		return "successfully inserted";
	}


}
