package com.application.moviebooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.moviebooking.DAO.MovieDao;
import com.application.moviebooking.model.Movie;
@Service
public class MovieService {
	
	@Autowired
	MovieDao movieDao;
	
	public String addMovieDetails(Movie movie){
		//System.out.println("movie");
		//movie.setLanguage(movie.getLanguage());
		//movie.setMoviename(movie.getMoviename());
		//movie.setReleasedate(movie.getReleasedate());
		movieDao.save(movie);
		return "successfully inserted";
	}
	//public List<Movie> getTheaters(Theater theater)
	      

}
