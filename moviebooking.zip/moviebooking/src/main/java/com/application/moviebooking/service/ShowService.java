package com.application.moviebooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.moviebooking.DAO.ShowDao;
import com.application.moviebooking.model.Show;
@Service
public class ShowService {
	
	@Autowired
	ShowDao showDao;
	
	public String addShowDetails(Show show){
		
		//show.setShowid(show.getShowid());
		//show.setDate(show.getDate());
		//show.setTheaterid(show.getTheaterid());
		//show.setMorningshow(show.getMorningshow());
		//show.setNoonshow(show.getNoonshow());
		//show.setEveningshow(show.getEveningshow());
		showDao.save(show);
		return "successfully inserted";
	}
	

}
