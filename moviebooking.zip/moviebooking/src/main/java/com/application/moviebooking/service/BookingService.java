package com.application.moviebooking.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.moviebooking.DAO.BookingDao;
import com.application.moviebooking.model.Booking;

@Service
public class BookingService {
	
	@Autowired
	BookingDao bookingDao;
	int id1=1;
	/*public String addBookingDetails(Booking booking){
		//booking.setBookingid(booking.getBookingid());
		//booking.setMoviename(booking.getMoviename());
		//booking.setTheatername(booking.getTheatername());
		//booking.setShowtime(booking.getShowtime());
		//booking.setDate(booking.getDate());
		//booking.setBookingid(booking.getBookingid());
		bookingDao.save(booking);
		return "successfully inserted";
	}*/
	
	
	Booking booking=new Booking();
	
	public String addBookingDetails(String moviename,String theatername,String showtime){
		//Booking booking=new Booking();
		//booking.setBookingid(id1++);
		System.out.println(id1);
		booking.setMoviename(moviename);
		booking.setTheatername(theatername);
		booking.setShowtime(showtime);
		LocalDate local=LocalDate.now();
		booking.setDate(local);
		booking.setUserid(+(++id1));
		bookingDao.save(booking);
		return "successfully created";
		
	}

}
