package com.application.moviebooking.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.moviebooking.DAO.MovieDao;
import com.application.moviebooking.DAO.ShowDao;
import com.application.moviebooking.DAO.TheaterDao;
import com.application.moviebooking.dto.TheaterDto;
import com.application.moviebooking.model.Show;
import com.application.moviebooking.model.Theater;
@Service
public class TheaterService {
	
	@Autowired
	TheaterDao theaterDao;
	@Autowired
	ShowDao showDao;
	
	public String addTheaterDetails(Theater theater){
		theater.setTheaterid(theater.getTheaterid());
		theater.setTheatername(theater.getTheatername());
		theater.setPlace(theater.getPlace());
		theaterDao.save(theater);
		return "successfully inserted";
	}
	
	public List<TheaterDto> detailsByMoviename(String moviename){
		List<Theater> th=theaterDao.findByName(moviename);
		List<TheaterDto> displaylist=new ArrayList<TheaterDto>();
		List<Show> show=showDao.findByMovieName(moviename);
		for(int i=0;i<show.size();i++)
		{
			System.out.println(show.get(i).getShowid()+" "+show.get(i).getTheaterid()+" "+show.get(i).getMorningshow()+" "+show.get(i).getNoonshow()+" "+show.get(i).getEveningshow());
		}
		for(int i=0;i<th.size();i++)
		{
			TheaterDto th1=new TheaterDto();
			th1.setName(th.get(i).getTheatername());
			th1.setPlace(th.get(i).getPlace());
			if(moviename.equals(show.get(i).getMorningshow())){
				th1.setShow("morning show");
			}
			else if(moviename.equals(show.get(i).getNoonshow())){
				th1.setShow("noon show");
			}
			else if(moviename.equals(show.get(i).getEveningshow())){
				th1.setShow("evening show");
			}
			displaylist.add(th1);
		}
		return displaylist;
	}

}
