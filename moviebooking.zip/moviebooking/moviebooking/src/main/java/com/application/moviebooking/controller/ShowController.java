package com.application.moviebooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.application.moviebooking.model.Show;
import com.application.moviebooking.service.ShowService;
@RestController
public class ShowController {
	
	@Autowired
	ShowService showservice;
	
	@PostMapping(value="Show/add")
	public String addShowDetails(@RequestBody Show show){
		String str=showservice.addShowDetails(show);
		return str;
	}

}
