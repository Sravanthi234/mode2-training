package com.application.moviebooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.moviebooking.DAO.ShowDao;
import com.application.moviebooking.model.Show;
@Service
public class ShowService {
	
	@Autowired
	ShowDao showDao;
	
	  /*adding show details*/
	public String addShowDetails(Show show){
		showDao.save(show);
		return "successfully inserted";
	}
	
}
