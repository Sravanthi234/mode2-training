package com.application.moviebooking.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.application.moviebooking.model.Show;
import com.application.moviebooking.model.Theater;

public interface ShowDao extends CrudRepository<Show,String>{
	
	@Query(value="select * from showtimings s where s.morningshow=?1 or s.noonshow=?1 or s.eveningshow=?1",nativeQuery=true)
			List<Show> findByMovieName(String moviename);
}
