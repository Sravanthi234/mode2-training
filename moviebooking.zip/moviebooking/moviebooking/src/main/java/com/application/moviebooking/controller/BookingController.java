package com.application.moviebooking.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.application.moviebooking.model.Booking;
import com.application.moviebooking.service.BookingService;

@RestController
public class BookingController {
	
	@Autowired
	BookingService bookingservice;
	
	@PostMapping(value="Booking/add/{name}/{theatername}/{showtime}")
	public String addBookingDetails(@PathVariable(value="name") String name,@PathVariable(value="theatername") String theatername,@PathVariable(value="showtime") String showtime){
		String str=bookingservice.addBookingDetails(name,theatername,showtime);
		return str;
	}

}





/*@PostMapping(value="Booking/add")
public String addBookingDetails(@RequestBody Booking booking){
	String str=bookingservice.addBookingDetails(booking);
	return str;
}*/
