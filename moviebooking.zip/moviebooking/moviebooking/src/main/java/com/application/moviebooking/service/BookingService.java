package com.application.moviebooking.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.moviebooking.DAO.BookingDao;
import com.application.moviebooking.model.Booking;

@Service
public class BookingService {
	
	@Autowired
	BookingDao bookingDao;
	int id1=1;
	
	Booking booking=new Booking();
	
	public String addBookingDetails(String moviename,String theatername,String showtime){
	
		System.out.println(id1);
		booking.setMoviename(moviename);
		booking.setTheatername(theatername);
		booking.setShowtime(showtime);
		LocalDate local=LocalDate.now();
		booking.setDate(local);
		booking.setUserid(+(++id1));
		bookingDao.save(booking);
		return "successfully created";
		
	}

}
