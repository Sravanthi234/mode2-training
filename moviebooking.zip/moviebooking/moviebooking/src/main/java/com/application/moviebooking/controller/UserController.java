package com.application.moviebooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.application.moviebooking.model.User;
import com.application.moviebooking.service.UserService;
@RestController
public class UserController {
	
	@Autowired
	UserService userservice;
	
	@PostMapping(value="User/add")
	public String addUserDetails(@RequestBody User user){
		String str=userservice.addUserDetails(user);
		return str;
	}

}
