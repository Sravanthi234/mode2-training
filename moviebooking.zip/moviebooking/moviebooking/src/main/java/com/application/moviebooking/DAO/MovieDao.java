package com.application.moviebooking.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.application.moviebooking.model.Movie;
@Repository
public interface MovieDao extends CrudRepository<Movie,String>{
	
	//@Query(value="select * from theater where theaterid IN(select theaterid from show table where morningshow=:moviename OR noonshow=:moviename OR eveningshow=:moviename") 
	
		//List<Movie> 

}
