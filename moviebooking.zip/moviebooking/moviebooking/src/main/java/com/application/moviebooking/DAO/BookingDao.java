package com.application.moviebooking.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.application.moviebooking.model.Booking;

@Repository
public interface BookingDao extends CrudRepository<Booking,Integer>{

}
