package com.application.moviebooking.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.application.moviebooking.model.Theater;
@Repository
public interface TheaterDao extends CrudRepository<Theater,Integer>{
	@Query(value="select * from theater t where t.theaterid in (select s.theaterid from showtimings s where s.morningshow=?1 or s.noonshow=?1 or s.eveningshow=?1)",nativeQuery=true)
     List<Theater> findByName(String moviename);
}
