package com.application.moviebooking.dto;

import java.time.LocalDate;

public class DisplayDto {
	
	String theaterid;
	String name;
	String place;
	String showid;
	String morningshow;
	String noonshow;
	String eveningshow;
	LocalDate date;

}
