package com.application.moviebooking.dto;

import java.util.List;

import com.application.moviebooking.model.Theater;

public class TheaterDto {
	 String theatername;
	 String place;
	 String show;
	 
	 
	public TheaterDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public TheaterDto(String theatername, String place, String show) {
		super();
		this.theatername = theatername;
		this.place = place;
		this.show = show;
	}


	public String getName() {
		return theatername;
	}
	public void setName(String name) {
		this.theatername = name;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getShow() {
		return show;
	}
	public void setShow(String show) {
		this.show = show;
	}


	/*public static List<Theater> findByName(String moviename) {
		// TODO Auto-generated method stub
		return null;
	}*/

}
