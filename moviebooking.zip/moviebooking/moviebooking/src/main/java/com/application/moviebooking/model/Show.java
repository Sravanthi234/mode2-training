package com.application.moviebooking.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Showtimings")
public class Show {
	@Id
	private String showid;
	LocalDate date;
	int theaterid;
	String morningshow;
	String noonshow;
	String eveningshow;
	
	public String getShowid() {
		return showid;
	}
	public void setShowid(String showid) {
		this.showid = showid;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public int getTheaterid() {
		return theaterid;
	}
	public void setTheaterid(int theaterid) {
		this.theaterid = theaterid;
	}
	public String getMorningshow() {
		return morningshow;
	}
	public void setMorningshow(String morningshow) {
		this.morningshow = morningshow;
	}
	public String getNoonshow() {
		return noonshow;
	}
	public void setNoonshow(String noonshow) {
		this.noonshow = noonshow;
	}
	public String getEveningshow() {
		return eveningshow;
	}
	public void setEveningshow(String eveningshow) {
		this.eveningshow = eveningshow;
	}
	
}
