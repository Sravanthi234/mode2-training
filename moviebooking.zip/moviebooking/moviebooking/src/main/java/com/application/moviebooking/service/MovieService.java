package com.application.moviebooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.moviebooking.DAO.MovieDao;
import com.application.moviebooking.model.Movie;
@Service
public class MovieService {
	
	@Autowired
	MovieDao movieDao;
	  
	  /*adding movie details*/
	public String addMovieDetails(Movie movie){
		movieDao.save(movie);
		return "successfully inserted";
	}
	      
}
