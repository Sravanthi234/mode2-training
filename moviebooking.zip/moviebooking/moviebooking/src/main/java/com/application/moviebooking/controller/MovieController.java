package com.application.moviebooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.application.moviebooking.model.Movie;
import com.application.moviebooking.service.MovieService;
@RestController
public class MovieController {
	
	@Autowired
	MovieService movieservice;
	
	@PostMapping(value="Movie/add")
	public String addMovieDetails(@RequestBody Movie movie){
		String str=movieservice.addMovieDetails(movie);
		return str;
	}
	
	/*  @PostMapping(value="Movie//{
	    public List detailsByMovieName(@RequestBody Movie movie){
		List list=movieservice.getMovieName
	}*/

}
