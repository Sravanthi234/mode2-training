package com.application.moviebooking.DAO;

import org.springframework.data.repository.CrudRepository;

import com.application.moviebooking.model.User;

public interface UserDao extends CrudRepository<User,String>{

}
