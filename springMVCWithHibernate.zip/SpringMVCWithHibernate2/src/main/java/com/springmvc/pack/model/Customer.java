package com.springmvc.pack.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer2")
public class Customer {
	@Column(name = "cust_name")
	private String cust_name;
	@Column(name = "cust_age")
	private int cust_age;
	@Column(name = "cust_phoneNo")
	private int cust_phoneNo;
	@Column(name = "cust_email")
	private String cust_email;
	@Column(name = "cust_job")
	private String cust_job;
	@Column(name = "cust_acc")
	private String cust_acc;
	@Column(name = "cust_passwd")
	private int cust_passwd;
	@Id
	@Column(name = "cust_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cust_id;

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public int getCust_age() {
		return cust_age;
	}

	public void setCust_age(int cust_age) {
		this.cust_age = cust_age;
	}

	public int getCust_phoneNo() {
		return cust_phoneNo;
	}

	public void setCust_phoneNo(int cust_phoneNo) {
		this.cust_phoneNo = cust_phoneNo;
	}

	public String getCust_email() {
		return cust_email;
	}

	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}

	public String getCust_job() {
		return cust_job;
	}

	public void setCust_job(String cust_job) {
		this.cust_job = cust_job;
	}

	public String getCust_acc() {
		return cust_acc;
	}

	public void setCust_acc(String cust_acc) {
		this.cust_acc = cust_acc;
	}

	public int getCust_passwd() {
		return cust_passwd;
	}

	public void setCust_passwd(int cust_passwd) {
		this.cust_passwd = cust_passwd;
	}

	public Integer getCust_id() {
		return cust_id;
	}

	public void setCust_id(Integer cust_id) {
		this.cust_id = cust_id;
	}

}
